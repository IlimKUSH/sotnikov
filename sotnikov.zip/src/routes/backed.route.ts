export enum BackendRoutes {
  user = '/user',
}