export enum BrowserRoute {
    main = '/',
    posts = '/posts',
    photos = '/photos',
    tasks = '/tasks',
  }
  